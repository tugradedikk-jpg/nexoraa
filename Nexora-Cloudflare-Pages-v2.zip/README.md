# Nexora — Cloudflare Pages güvenlik paneli

Türkçe, mobil uyumlu, siyah-mor neon arayüz; kullanıcının verdiği siyah-beyaz retro görsel arka plan olarak kullanılır. Cloudflare Pages Functions + D1 ile hesap oluşturma/giriş, güvenli oturum çerezi, DNS sorgulama ve tarayıcıda çalışan parola dayanıklılığı aracı.

## Özellikler
- E-posta/parola ile hesap oluşturma ve giriş
- Parolalar PBKDF2-HMAC-SHA256 (310.000 iterasyon, rastgele salt) ile hash'lenir; düz metin saklanmaz
- HMAC imzalı, rastgele oturum belirteci; veritabanında yalnızca belirtecin SHA-256 özeti saklanır
- HttpOnly + Secure + SameSite=Lax oturum çerezi
- Cloudflare D1 kullanıcı/oturum tabloları
- A, AAAA, MX, TXT, NS, CNAME, CAA DNS sorguları
- Parola kontrolü tarayıcıda yapılır; parola API'ye gönderilmez
- Güvenlik başlıkları ve mobil düzen

## 1. Cloudflare Pages projesi
1. GitHub'da yeni, boş bir repo oluştur: `nexora-security-panel`.
2. Bu ZIP içindeki dosyaları repo köküne çıkarıp yükle.
3. Cloudflare Dashboard → **Workers & Pages** → **Create** → **Pages** → **Connect to Git**.
4. Repo'yu seç. Framework preset: **None**. Build command alanını boş bırak; Build output directory alanına `.` yaz. Deploy et.

> `functions/` klasörü repo kökünde olmalı; `public/` içine taşıma. Pages Functions bu klasörden algılanır.

## 2. D1 veritabanı
1. Cloudflare Dashboard → **Storage & databases** → **D1 SQL Database** → Create database.
2. Adı `nexora-db` olsun.
3. Veritabanının **Console** bölümünde `schema.sql` içeriğini çalıştır.
4. Pages projesi → **Settings** → **Bindings** → **Add** → **D1 database**.
5. Variable name `DB`, database olarak `nexora-db` seç. Kaydet ve yeni deploy başlat.

## 3. Oturum gizli anahtarı
1. Pages projesi → **Settings** → **Environment variables**.
2. Production için `SESSION_SECRET` isimli bir **secret** ekle. En az 32 karakterlik, rastgele bir değer kullan. Örnek üretim komutu:
   - Windows PowerShell: `[Convert]::ToBase64String([Security.Cryptography.RandomNumberGenerator]::GetBytes(48))`
3. Aynı secret'ı Preview ortamına da eklemek istiyorsan ayrıca tanımla.
4. Kaydet ve yeniden deploy et.

Gizli anahtarı HTML/JS dosyasına yazma, GitHub'a koyma veya kimseyle paylaşma.

## 4. Yayın sonrası test
- `https://SENIN-PROJEN.pages.dev` adresini aç.
- Yeni hesap oluştur; sonra çıkış yapıp tekrar giriş yap.
- DNS aracında `example.com` ve `A` türünü sorgula.
- Tarayıcıyı yenile: oturum geçerliyse panel açık kalmalı.
- Mobil görünümü telefon genişliğinde kontrol et.

## Yerel geliştirme (isteğe bağlı)
Cloudflare Wrangler için Node.js gerekir:
```bash
npm install -g wrangler
wrangler pages dev .
```
Yerel testte `.dev.vars` dosyasında `SESSION_SECRET="en az 32 karakterlik yerel deneme anahtarı"` tanımla; D1 yerel binding ayarı ayrıca yapılandırılmalıdır. `.dev.vars` dosyasını GitHub'a yükleme.

## Güvenlik notları ve sınırlamalar
- Bu bir başlangıç projesidir, bağımsız güvenlik denetiminden geçmiş bir ürün değildir.
- Yayına açmadan önce oran sınırlama (özellikle giriş/kayıt), e-posta doğrulama, parola sıfırlama ve izleme ekle. Cloudflare Turnstile da düşünülebilir.
- Şu an kayıt olan herkes kendi hesabını açabilir; admin paneli veya rol sistemi yok.
- Parola kontrolü tahmini bir göstergedir; parola sızıntısı kontrolü yapmaz.
- DNS aracı yalnızca herkese açık DNS kayıtlarını sorgular; sisteme giriş/istismar veya gizli veri toplama yapmaz.
