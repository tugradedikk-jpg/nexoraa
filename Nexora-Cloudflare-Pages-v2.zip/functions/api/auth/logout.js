import {json,cookieValue,currentUser} from "./_utils.js";
export async function onRequestPost({request,env}) {
  try { const user=await currentUser(request,env);if(user&&env.DB)await env.DB.prepare("DELETE FROM sessions WHERE token_hash=?1").bind(user.tokenHash).run(); }
  catch {}
  return json({ok:true},200,{"Set-Cookie":"nexora_session=; Path=/; HttpOnly; Secure; SameSite=Lax; Max-Age=0"});
}
