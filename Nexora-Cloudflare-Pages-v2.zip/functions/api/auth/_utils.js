const enc = new TextEncoder();
export const json = (data, status=200, headers={}) => new Response(JSON.stringify(data), {status, headers:{"Content-Type":"application/json; charset=utf-8","Cache-Control":"no-store",...headers}});
export const fail = (message,status=400) => json({error:message},status);
export function cookieValue(request,name) {
  const header=request.headers.get("Cookie")||"";
  for (const item of header.split(";")) { const [key,...rest]=item.trim().split("="); if(key===name)return rest.join("="); }
  return null;
}
export function base64url(bytes) {
  let s=""; for(const b of bytes)s+=String.fromCharCode(b);
  return btoa(s).replace(/\+/g,"-").replace(/\//g,"_").replace(/=+$/,"");
}
export function fromBase64url(s) {
  s=s.replace(/-/g,"+").replace(/_/g,"/"); while(s.length%4)s+="=";
  const bin=atob(s); return Uint8Array.from(bin,c=>c.charCodeAt(0));
}
export async function sha256(value) {
  const out=await crypto.subtle.digest("SHA-256",enc.encode(value)); return base64url(new Uint8Array(out));
}
export async function hmac(value,secret) {
  const key=await crypto.subtle.importKey("raw",enc.encode(secret),{name:"HMAC",hash:"SHA-256"},false,["sign"]);
  return base64url(new Uint8Array(await crypto.subtle.sign("HMAC",key,enc.encode(value))));
}
export async function newSession(env,userId) {
  if(!env.SESSION_SECRET || env.SESSION_SECRET.length<32) throw new Error("SESSION_SECRET ayarı eksik veya çok kısa.");
  const raw=new Uint8Array(32); crypto.getRandomValues(raw); const token=base64url(raw);
  const expires=Date.now()+7*24*60*60*1000;
  await env.DB.prepare("INSERT INTO sessions (token_hash,user_id,expires_at,created_at) VALUES (?1,?2,?3,?4)")
    .bind(await sha256(token),userId,expires,Date.now()).run();
  const signed=token+"."+await hmac(token,env.SESSION_SECRET);
  return {cookie:`nexora_session=${signed}; Path=/; HttpOnly; Secure; SameSite=Lax; Max-Age=604800`,expires};
}
export async function currentUser(request,env) {
  const value=cookieValue(request,"nexora_session"); if(!value || !env.DB || !env.SESSION_SECRET)return null;
  const dot=value.lastIndexOf("."); if(dot<1)return null;
  const token=value.slice(0,dot), signature=value.slice(dot+1);
  const expected=await hmac(token,env.SESSION_SECRET);
  if(signature.length!==expected.length)return null;
  const a=enc.encode(signature),b=enc.encode(expected); let diff=0; for(let i=0;i<a.length;i++)diff|=a[i]^b[i]; if(diff!==0)return null;
  const tokenHash=await sha256(token);
  const row=await env.DB.prepare("SELECT users.id, users.email, sessions.expires_at FROM sessions JOIN users ON users.id=sessions.user_id WHERE sessions.token_hash=?1").bind(tokenHash).first();
  if(!row || row.expires_at<Date.now()) { if(row) await env.DB.prepare("DELETE FROM sessions WHERE token_hash=?1").bind(tokenHash).run(); return null; }
  return {id:row.id,email:row.email,tokenHash};
}
export async function readJson(request) {
  try { return await request.json(); } catch { return null; }
}
export const emailOk = email => typeof email==="string" && email.length<=254 && /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email);
export async function passwordHash(password,salt) {
  const key=await crypto.subtle.importKey("raw",enc.encode(password),"PBKDF2",false,["deriveBits"]);
  const bits=await crypto.subtle.deriveBits({name:"PBKDF2",salt,iterations:310000,hash:"SHA-256"},key,256);
  return base64url(new Uint8Array(bits));
}
