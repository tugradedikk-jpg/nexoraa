import {json,currentUser} from "./_utils.js";
export async function onRequestGet({request,env}) {
  try { const user=await currentUser(request,env); return json({user:user?{email:user.email}:null}); }
  catch { return json({user:null}); }
}
