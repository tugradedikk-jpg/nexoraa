import {json,fail,readJson,emailOk,passwordHash,base64url,newSession} from "./_utils.js";
export async function onRequestPost({request,env}) {
  if(!env.DB)return fail("Veritabanı bağlı değil. README adımlarını tamamla.",503);
  const body=await readJson(request); if(!body)return fail("Geçersiz istek.");
  const email=String(body.email||"").trim().toLowerCase(), password=body.password;
  if(!emailOk(email))return fail("Geçerli bir e-posta adresi gir.");
  if(typeof password!=="string"||password.length<10||password.length>128)return fail("Parola 10–128 karakter arasında olmalı.");
  if(!env.SESSION_SECRET||env.SESSION_SECRET.length<32)return fail("SESSION_SECRET ayarı eksik. README dosyasına bak.",503);
  const existing=await env.DB.prepare("SELECT id FROM users WHERE email=?1").bind(email).first();
  if(existing)return fail("Bu e-posta ile hesap zaten var.",409);
  const salt=new Uint8Array(16);crypto.getRandomValues(salt);
  const hash=await passwordHash(password,salt);
  let result;
  try { result=await env.DB.prepare("INSERT INTO users (email,password_hash,password_salt,created_at) VALUES (?1,?2,?3,?4)").bind(email,hash,base64url(salt),Date.now()).run(); }
  catch { return fail("Hesap oluşturulamadı. Bu e-posta kullanılıyor olabilir.",409); }
  const id=result.meta?.last_row_id;
  if(!id)return fail("Hesap oluşturuldu ancak oturum açılamadı. Giriş yapmayı dene.",500);
  try { const session=await newSession(env,id); return json({user:{email} },201,{"Set-Cookie":session.cookie}); }
  catch { return fail("Hesap oluşturuldu. Oturum açmak için giriş yap.",500); }
}
