import {json,fail,readJson,emailOk,passwordHash,fromBase64url,newSession} from "./_utils.js";
export async function onRequestPost({request,env}) {
  if(!env.DB)return fail("Veritabanı bağlı değil. README adımlarını tamamla.",503);
  const body=await readJson(request);if(!body)return fail("Geçersiz istek.");
  const email=String(body.email||"").trim().toLowerCase(),password=body.password;
  if(!emailOk(email)||typeof password!=="string"||password.length>128)return fail("E-posta veya parola hatalı.",401);
  const user=await env.DB.prepare("SELECT id,email,password_hash,password_salt FROM users WHERE email=?1").bind(email).first();
  if(!user)return fail("E-posta veya parola hatalı.",401);
  const actual=await passwordHash(password,fromBase64url(user.password_salt));
  if(actual!==user.password_hash)return fail("E-posta veya parola hatalı.",401);
  try { const session=await newSession(env,user.id);return json({user:{email:user.email}},200,{"Set-Cookie":session.cookie}); }
  catch { return fail("Oturum açılamadı. Sunucu ayarlarını kontrol et.",503); }
}
