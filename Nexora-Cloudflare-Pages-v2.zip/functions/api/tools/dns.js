import {json,fail,currentUser} from "../auth/_utils.js";
const TYPES={A:1,AAAA:28,MX:15,TXT:16,NS:2,CNAME:5,CAA:257};
export async function onRequestGet({request,env}) {
  const user=await currentUser(request,env).catch(()=>null);if(!user)return fail("Giriş yapman gerekiyor.",401);
  const url=new URL(request.url),domain=(url.searchParams.get("domain")||"").trim().toLowerCase().replace(/\.$/,""),type=(url.searchParams.get("type")||"A").toUpperCase();
  if(!TYPES[type])return fail("Desteklenmeyen DNS kayıt türü.");
  if(domain.length>253||!domain||domain.includes("://")||domain.includes("/")||domain.includes("@")||!domain.split(".").every(label=>/^(?!-)[a-z0-9-]{1,63}(?<!-)$/.test(label)))return fail("Geçerli bir alan adı gir (ör. example.com).");
  try {
    const response=await fetch(`https://cloudflare-dns.com/dns-query?name=${encodeURIComponent(domain)}&type=${TYPES[type]}`,{headers:{accept:"application/dns-json"},cf:{cacheTtl:60}});
    if(!response.ok)return fail("DNS sağlayıcısından yanıt alınamadı.",502);
    const result=await response.json();
    const answers=(result.Answer||[]).filter(a=>a.type===TYPES[type]).map(a=>({type,data:String(a.data).slice(0,1000)}));
    return json({domain,type,answers,status:result.Status});
  } catch { return fail("DNS sorgusu başarısız oldu. Daha sonra tekrar dene.",502); }
}
