const $ = (s) => document.querySelector(s);
const $$ = (s) => [...document.querySelectorAll(s)];
let authMode = "login";
const authView = $("#authView"), dashboardView = $("#dashboardView");
$("#year").textContent = new Date().getFullYear();
$("#todayLabel").textContent = new Intl.DateTimeFormat("tr-TR",{day:"numeric",month:"short",year:"numeric"}).format(new Date());

function setAuthMode(mode) {
  authMode = mode;
  $$(".auth-tab").forEach(b => b.classList.toggle("active", b.dataset.mode === mode));
  $("#authTitle").textContent = mode === "login" ? "Tekrar hoş geldin." : "Nexora'ya katıl.";
  $("#authSubtitle").textContent = mode === "login" ? "Paneline erişmek için giriş yap." : "Kişisel çalışma alanını oluştur.";
  $("#authSubmit").innerHTML = mode === "login" ? 'Panele giriş yap <span>↗</span>' : 'Hesap oluştur <span>↗</span>';
  $("#passwordHint").classList.toggle("hidden", mode !== "register");
  $("#password").autocomplete = mode === "login" ? "current-password" : "new-password";
  $("#authMessage").textContent = "";
}
$$(".auth-tab").forEach(b => b.addEventListener("click", () => setAuthMode(b.dataset.mode)));

function showDashboard(email) {
  authView.classList.add("hidden"); dashboardView.classList.remove("hidden");
  $("#logoutBtn").classList.remove("hidden"); $("#accountEmail").textContent = email;
  $("#avatar").textContent = (email[0] || "N").toUpperCase();
  showPage("overview");
}
function showAuth() {
  dashboardView.classList.add("hidden"); authView.classList.remove("hidden");
  $("#logoutBtn").classList.add("hidden");
}
function showPage(page) {
  const titles = {overview:["Genel bakış","Güvenlik araçlarına tek yerden eriş."],dns:["DNS sorgulama","Herkese açık DNS kayıtlarını incele."],password:["Parola kontrolü","Parola dayanıklılığını cihazında değerlendir."]};
  $$(".page").forEach(p => p.classList.add("hidden"));
  $("#"+page+"Page").classList.remove("hidden");
  $$(".nav-item").forEach(b => b.classList.toggle("active", b.dataset.page === page));
  $("#pageTitle").textContent = titles[page][0]; $("#pageDesc").textContent = titles[page][1];
}
$$(".nav-item").forEach(b => b.addEventListener("click", () => showPage(b.dataset.page)));
$$(".tool-card").forEach(b => b.addEventListener("click", () => showPage(b.dataset.goto)));

async function api(url, options={}) {
  const response = await fetch(url, {credentials:"same-origin", ...options, headers:{"Content-Type":"application/json", ...(options.headers||{})}});
  const data = await response.json().catch(() => ({}));
  if (!response.ok) throw new Error(data.error || "İstek tamamlanamadı.");
  return data;
}
async function checkSession() {
  try { const data = await api("/api/auth/me", {method:"GET",headers:{}}); if (data.user) showDashboard(data.user.email); else showAuth(); }
  catch { showAuth(); }
}
$("#authForm").addEventListener("submit", async (e) => {
  e.preventDefault();
  const btn = $("#authSubmit"), message = $("#authMessage");
  btn.disabled = true; btn.textContent = "İşleniyor…"; message.textContent = ""; message.className = "message";
  try {
    const data = await api(`/api/auth/${authMode}`, {method:"POST",body:JSON.stringify({email:$("#email").value.trim(),password:$("#password").value})});
    $("#password").value = ""; showDashboard(data.user.email);
  } catch(err) { message.textContent = err.message; }
  finally { btn.disabled = false; $("#authSubmit").innerHTML = authMode === "login" ? 'Panele giriş yap <span>↗</span>' : 'Hesap oluştur <span>↗</span>'; }
});
$("#logoutBtn").addEventListener("click", async () => { try { await api("/api/auth/logout",{method:"POST",body:"{}"}); } catch {} showAuth(); });

$("#dnsForm").addEventListener("submit", async (e) => {
  e.preventDefault();
  const message=$("#dnsMessage"), results=$("#dnsResults");
  message.textContent="DNS kayıtları sorgulanıyor…"; message.className="message"; results.classList.add("hidden"); results.innerHTML="";
  try {
    const data=await api(`/api/tools/dns?domain=${encodeURIComponent($("#domain").value.trim())}&type=${encodeURIComponent($("#recordType").value)}`,{method:"GET",headers:{}});
    message.textContent=`${data.domain} için ${data.answers.length} kayıt bulundu.`; message.className="message success";
    if (!data.answers.length) { results.innerHTML='<div class="result-row"><span>Bilgi</span><span>Bu türde kayıt bulunamadı.</span></div>'; }
    else results.innerHTML='<div class="result-head"><span>Tür</span><span>Değer</span></div>'+data.answers.map(a=>`<div class="result-row"><span>${escapeHtml(a.type)}</span><span>${escapeHtml(a.data)}</span></div>`).join("");
    results.classList.remove("hidden");
  } catch(err) { message.textContent=err.message; }
});
function escapeHtml(v){return String(v).replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));}

const passwordInput=$("#localPassword");
$("#togglePassword").addEventListener("click",()=>{passwordInput.type=passwordInput.type==="password"?"text":"password";$("#togglePassword").textContent=passwordInput.type==="password"?"Göster":"Gizle";});
passwordInput.addEventListener("input",()=>{
  const p=passwordInput.value, checks=[p.length>=12,/[a-z]/.test(p)&&/[A-Z]/.test(p),/\d/.test(p),/[^A-Za-z0-9]/.test(p)];
  const score=checks.filter(Boolean).length; $("#strengthScore").textContent=`${score} / 4`;
  $("#strengthText").textContent=!p?"Henüz kontrol edilmedi":score<=1?"Zayıf":score===2?"Orta":score===3?"İyi":"Güçlü";
  $("#strengthBar").style.width=(score*25)+"%"; $("#strengthBar").style.background=score<=1?"#fb7185":score===2?"#fbbf24":score===3?"#a879ff":"#5de2b1";
  $$("#passwordChecks li").forEach((li,i)=>{li.classList.toggle("pass",checks[i]);});
});
checkSession();
